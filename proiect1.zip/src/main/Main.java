package main;

import children.AnualAgeRevision;
import children.Child;
import children.UptadeChildrenData;
import designpatterns.factory.AgeCategoryFactory;
import designpatterns.factory.AverageScoreFactory;
import designpatterns.Strategy.AverageScoreStrategy;
import fileio.AnualChangesInputData;
import fileio.BudgetCalculator;
import fileio.ChildrenInputData;
import fileio.Input;
import fileio.InputLoader;
import fileio.SantaGiftsInputData;
import fileio.Writer;
import gifts.AddGifts;
import gifts.SantaGiftList;
import checker.Checker;
import common.Constants;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * Class used to run the code
 */
public final class Main {

    private Main() {
        ///constructor for checkstyle
    }
    /**
     * This method is used to call the checker which calculates the score
     * @param args
     *          the arguments used to call the main method
     */
    public static void main(final String[] args) throws IOException {

        File outputDirectory = new File("output/");
        File[] directory = outputDirectory.listFiles();
        if (directory != null) {
            for (File file : directory) {
                if (!file.delete()) {
                    System.out.println("nu s-a sters");
                }
            }
        }

        for (int i = 1; i <= Constants.TESTS_NUMBER; i++) {
            String filepath = Constants.OUTPUT_PATH + i + Constants.FILE_EXTENSION;
            File out = new File(filepath);
            boolean isCreated = out.createNewFile();
            if (isCreated) {
                String testpath = Constants.TEST_PATH + i + Constants.FILE_EXTENSION;
                action(testpath, filepath);
            }
        }

        Checker.calculateScore();
    }

    /**
     * method that calls other function to determinate the wanted result
     */

    public static void action(final String filePath1,
                              final String filePath2) throws IOException {
        InputLoader inputLoader = new InputLoader(filePath1);
        Input input = inputLoader.readData();
        Writer fileWriter = new Writer(filePath2);
        JSONArray arrayResult = new JSONArray();
        JSONObject anualChildren = new JSONObject();
        long numberofyears = input.getNumberOfYears();
        List<ChildrenInputData> children = input.getChildren();
        List<SantaGiftsInputData> santaGifts = input.getGifts();
        List<AnualChangesInputData> changes = input.getChanges();


        AgeCategoryFactory ageCategoryFactory = new AgeCategoryFactory();

        ArrayList<Child> santaChildrenList = new ArrayList<>();

        for (int i = 0; i < children.size(); i++) {
            Child child = new Child(children.get(i));
            ageCategoryFactory.ageCategory(child);
            if (child.getAgeCategory() != Constants.AgeCategory.ADULT) {
                AverageScoreStrategy averageScoreStrategy = new AverageScoreFactory()
                        .createStrategy(child);
                child.setAverageScore(averageScoreStrategy.getAverageScore());
                santaChildrenList.add(child);
            }
        }
        BudgetCalculator budgetCalculator = new BudgetCalculator(
                input.getSantaBudget(), santaChildrenList);

        ArrayList<SantaGiftList> santaGiftLists = new ArrayList<>();
        for (int i = 0; i < santaGifts.size(); i++) {
            SantaGiftList santaGift = new SantaGiftList(santaGifts.get(i));
            santaGiftLists.add(santaGift);
        }
        Collections.sort(santaGiftLists);

        AddGifts addGifts = new AddGifts(santaChildrenList, santaGiftLists);

        fileWriter.writeJSON(arrayResult, santaChildrenList);


        for (int i = 0; i < numberofyears; i++) {
            AnualAgeRevision anualAgeRevision = new AnualAgeRevision(
                    santaChildrenList, ageCategoryFactory);
            for (int k = 0; k < changes.get(i).getNewChildren().size(); k++) {
                Child newChild = new Child(changes.get(i)
                        .getNewChildren().get(k));
                ageCategoryFactory.ageCategory(newChild);
                if (newChild.getAgeCategory() != Constants.AgeCategory.ADULT) {
                    AverageScoreStrategy averageScoreStrategy = new AverageScoreFactory()
                            .createStrategy(newChild);
                    newChild.setAverageScore(averageScoreStrategy.getAverageScore());
                    santaChildrenList.add(newChild);
                }
            }
            UptadeChildrenData uptadeChildrenData = new UptadeChildrenData(santaChildrenList,
                    changes.get(i).getChildrenUpdates());
            budgetCalculator = new BudgetCalculator(changes.get(i).
                    getNewSantaBudget(), santaChildrenList);
            for (int k = 0; k < changes.get(k).getNewGifts().size(); k++) {
                SantaGiftList santaGift = new SantaGiftList(changes.get(k).getNewGifts().get(k));
                santaGiftLists.add(santaGift);
            }
            Collections.sort(santaGiftLists);
            addGifts = new AddGifts(santaChildrenList, santaGiftLists);
            fileWriter.writeJSON(arrayResult, santaChildrenList);
        }

        anualChildren.put("annualChildren", arrayResult);



        fileWriter.closeJSON(anualChildren);
    }
}
