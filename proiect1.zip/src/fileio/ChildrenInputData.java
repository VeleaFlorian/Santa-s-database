package fileio;

import java.util.ArrayList;

public class ChildrenInputData extends ShowInput {

    private final String lastName;

    private final String firstName;

    private final int age;

    private final String city;

    public ChildrenInputData(final Integer id, final String lastName,
                             final String firstName, final Integer age,
                             final String city, final Double niceScore,
                             final ArrayList<String> giftsPreferences) {
        super(id, niceScore, giftsPreferences);
        this.lastName = lastName;
        this.firstName = firstName;
        this.age = age;
        this.city = city;
    }

    public final String getLastName() {
        return lastName;
    }

    public final String getFirstName() {
        return firstName;
    }

    public final int getAge() {
        return age;
    }

    public final String getCity() {
        return city;
    }

    @Override
    public final String toString() {
        return "ChildrenInputData{" + " id= "
                + super.getId() + " lastName= "
                + getLastName() + " firstName= "
                + getFirstName() + " age= "
                + getAge() + " city= "
                + getCity() + " niceScore= "
                + super.getNiceScore() + " GiftList= "
                + super.getGifts() + " } \n ";
    }
}
