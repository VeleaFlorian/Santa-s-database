package fileio;

public class SantaGiftsInputData {
    private final String productName;

    private final String category;

    private final int price;

    public SantaGiftsInputData(final String productName,
                               final int price, final String category) {
        this.productName = productName;
        this.category = category;
        this.price = price;
    }

    public final String getProductName() {
        return productName;
    }

    public final String getCategory() {
        return category;
    }

    public final int getPrice() {
        return price;
    }

    @Override
    public final String toString() {
        return "SantaGiftsInputData{"
                + "productName='"
                + productName
                + '\''
                + ", category='"
                + category
                + '\''
                + ", price="
                + price
                + '}';
    }
}
