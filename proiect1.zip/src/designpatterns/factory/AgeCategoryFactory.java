package designpatterns.factory;

import children.Child;
import common.Constants;

public class AgeCategoryFactory {

    /**
     * Method to set the age category for children.
     */

    public final void ageCategory(final Child child) {
        if (child.getAge() < Constants.BABY) {
            child.setAgeCategory(Constants.AgeCategory.BABY);
            return;
        }

        if (child.getAge() < Constants.KID) {
            child.setAgeCategory(Constants.AgeCategory.KID);
            return;
        }
        if (child.getAge() <= Constants.TEEN) {
            child.setAgeCategory(Constants.AgeCategory.TEEN);
            return;
        }
        if (child.getAge() > Constants.BABY) {
            child.setAgeCategory(Constants.AgeCategory.ADULT);
            return;
        }
    }
}
