package fileio;

import java.util.ArrayList;


public abstract class ShowInput {

    private final int id;

    private final double niceScore;

    private final ArrayList<String> gifts;



    public ShowInput(final Integer id, final double niceScore,
                     final ArrayList<String> gifts) {
        this.id = id;
        this.niceScore = niceScore;
        this.gifts = gifts;
    }

    public final int getId() {
        return id;
    }


    public final Double getNiceScore() {
        return niceScore;
    }



    public final ArrayList<String> getGifts() {
        return gifts;
    }
}
