package children;

import gifts.SantaGiftList;
import common.Constants;
import fileio.ChildrenInputData;

import java.util.ArrayList;

public class Child {
    private int id;
    private String lastName;
    private String firstName;
    private String city;
    private int age;
    private ArrayList<String> giftsPreferences;
    private double averageScore;
    private ArrayList<Double> niceScoreHistory;
    private double assignedBudget;
    private ArrayList<SantaGiftList> giftsReceived;
    private Constants.AgeCategory ageCategory;

    public Child(final ChildrenInputData child) {
        this.id = child.getId();
        this.lastName = child.getLastName();
        this.firstName = child.getFirstName();
        this.city = child.getCity();
        this.age = child.getAge();
        this.giftsPreferences = child.getGifts();
        this.averageScore = child.getNiceScore();
        this.niceScoreHistory = new ArrayList<>();
        this.assignedBudget = 0;
        this.giftsReceived = new ArrayList<>();
        this.ageCategory = null;
    }

    public final Constants.AgeCategory getAgeCategory() {
        return ageCategory;
    }

    public final void setAgeCategory(final Constants.AgeCategory ageCategory) {
        this.ageCategory = ageCategory;
    }

    public final int getId() {
        return id;
    }

    public final void setId(final int id) {
        this.id = id;
    }

    public final String getLastName() {
        return lastName;
    }

    public final void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    public final String getFirstName() {
        return firstName;
    }

    public final void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    public final String getCity() {
        return city;
    }

    public final void setCity(final String city) {
        this.city = city;
    }

    public final int getAge() {
        return age;
    }

    public final void setAge(final int age) {
        this.age = age;
    }

    public final ArrayList<String> getGiftsPreferences() {
        return giftsPreferences;
    }

    public final void setGiftsPreferences(final ArrayList<String> giftsPreferences) {
        this.giftsPreferences = giftsPreferences;
    }

    public final double getAverageScore() {
        return averageScore;
    }

    public final void setAverageScore(final double averageScore) {
        this.averageScore = averageScore;
    }

    public final ArrayList<Double> getNiceScoreHistory() {
        return niceScoreHistory;
    }

    public final void setNiceScoreHistory(final ArrayList<Double> niceScoreHistory) {
        this.niceScoreHistory = niceScoreHistory;
    }

    public final double getAssignedBudget() {
        return assignedBudget;
    }

    public final void setAssignedBudget(final double assignedBudget) {
        this.assignedBudget = assignedBudget;
    }

    public final ArrayList<SantaGiftList> getGiftsReceived() {
        return giftsReceived;
    }


    @Override
    public final String toString() {
        return "Child{"
                + "id="
                + id
                + ", lastName='"
                + lastName
                + '\''
                + ", firstName='"
                + firstName
                + '\''
                + ", city='"
                + city
                + '\''
                + ", age="
                + age
                + ", giftsPreferences="
                + giftsPreferences
                + ", averageScore="
                + averageScore
                + ", niceScoreHistory="
                + niceScoreHistory
                + ", assignedBudget="
                + assignedBudget
                + ", giftsReceived="
                + giftsReceived
                + '}';
    }
}
