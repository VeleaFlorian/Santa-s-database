package gifts;

import children.Child;

import java.util.ArrayList;

public class AddGifts {

    private double budget;

    public AddGifts(final ArrayList<Child> child,
                    final ArrayList<SantaGiftList> santaGiftList) {

        emptyList(child);
        for (int k = 0; k < child.size(); k++) {
            budget = child.get(k).getAssignedBudget();
            for (int i = 0; i < child.get(k).getGiftsPreferences().size(); i++) {
                for (int j = 0; j < santaGiftList.size(); j++) {
                    if (santaGiftList.get(j).getCategory().
                            equals(child.get(k).getGiftsPreferences().get(i))) {
                        if (budget >= santaGiftList.get(j).getPrice()) {
                            budget = budget - santaGiftList.get(j).getPrice();
                            child.get(k).getGiftsReceived().add(santaGiftList.get(j));
                            break;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * method that empties the list of the old gifts
     */

    public final void emptyList(final ArrayList<Child> child) {
        for (int i = 0; i < child.size(); i++) {
            if (child.get(i).getGiftsReceived() != null) {
                for (int k = 0; k < child.get(i).getGiftsReceived().size(); k++) {
                    child.get(i).getGiftsReceived().remove(k);
                    k--;
                }
            }
        }
    }

}
