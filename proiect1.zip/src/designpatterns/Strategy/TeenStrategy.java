package designpatterns.Strategy;

import children.Child;

public class TeenStrategy implements AverageScoreStrategy {

    private double sum = 0;

    public TeenStrategy(final Child child) {
        double indexSum = 0;
        if (child.getNiceScoreHistory().size() == 0) {
            sum = child.getAverageScore();
            child.getNiceScoreHistory().add(sum);
            return;
        }
        for (int i = 1; i <= child.getNiceScoreHistory().size(); i++) {
            sum = sum + child.getNiceScoreHistory().get(i - 1) * i;
            indexSum = indexSum + i;
        }
        sum = sum / indexSum;
    }

    @Override
    public final double getAverageScore() {

        return sum;
    }
}
