package fileio;

import java.util.List;

/**
 * The class contains information about input
 * <p>
 * DO NOT MODIFY
 */
public final class Input {
    /**
     * number of years
     */
    private final long numberOfYears;
    /**
     * Santa budget
     */
    private final long santaBudget;
    /**
     * List of children
     */
    private final List<ChildrenInputData> children;
    /**
     * List of gifts
     */
    private final List<SantaGiftsInputData> gifts;
    /**
     * List of serials aka tv shows
     */
    private final List<AnualChangesInputData> changes;

    public Input() {
        this.numberOfYears = Long.parseLong(null);
        this.santaBudget = Long.parseLong(null);
        this.children = null;
        this.gifts = null;
        this.changes = null;
    }

    public Input(final long numberOfYears, final long santaBudget,
                 final List<ChildrenInputData> children,
                 final List<SantaGiftsInputData> gifts,
                 final List<AnualChangesInputData> changes) {
        this.numberOfYears = numberOfYears;
        this.santaBudget = santaBudget;
        this.children = children;
        this.gifts = gifts;
        this.changes = changes;
    }

    public long getNumberOfYears() {
        return numberOfYears;
    }

    public long getSantaBudget() {
        return santaBudget;
    }

    public List<ChildrenInputData> getChildren() {
        return children;
    }

    public List<SantaGiftsInputData> getGifts() {
        return gifts;
    }

    public List<AnualChangesInputData> getChanges() {
        return changes;
    }
}

