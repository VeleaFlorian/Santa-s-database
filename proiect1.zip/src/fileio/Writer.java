package fileio;

import children.Child;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * The class writes the output in files
 * <p>
 * DO NOT MODIFY
 */
public final class Writer {
    /**
     * The file where the data will be written
     */
    private final FileWriter file;

    public Writer(final String path) throws IOException {
        this.file = new FileWriter(path);
    }
    /**
     * method that closes the JSON file.
     */

    public void closeJSON(final JSONObject object) {
        try {
            file.write(object.toJSONString());
            file.flush();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * method that writes the JSON file with the wanted data.
     */

    public void writeJSON(final JSONArray array, final ArrayList<Child> children) {
        JSONArray annualChildren = new JSONArray();
        JSONObject jsonChildren = new JSONObject();
        for (int i = 0; i < children.size(); i++) {
            JSONObject child = new JSONObject();
            child.put("id", children.get(i).getId());
            child.put("lastName", children.get(i).getLastName());
            child.put("firstName", children.get(i).getFirstName());
            child.put("city", children.get(i).getCity());
            child.put("age", children.get(i).getAge());
            JSONArray giftPreferences = new JSONArray();
            for (int k = 0; k < children.get(i).getGiftsPreferences().size(); k++) {
                giftPreferences.add(children.get(i).getGiftsPreferences().get(k));
            }
            child.put("giftsPreferences", giftPreferences);
            child.put("averageScore", children.get(i).getAverageScore());
            JSONArray niceScoreHistory = new JSONArray();
            for (int k = 0; k < children.get(i).getNiceScoreHistory().size(); k++) {
                niceScoreHistory.add(children.get(i).getNiceScoreHistory().get(k));
            }
            child.put("niceScoreHistory", niceScoreHistory);
            child.put("assignedBudget", children.get(i).getAssignedBudget());
            JSONArray giftRecevied = new JSONArray();
            for (int k = 0; k < children.get(i).getGiftsReceived().size(); k++) {
                JSONObject gift = new JSONObject();
                gift.put("productName", children.get(i).getGiftsReceived().get(k).getProductName());
                gift.put("price", children.get(i).getGiftsReceived().get(k).getPrice());
                gift.put("category", children.get(i).getGiftsReceived().get(k).getCategory());
                giftRecevied.add(gift);
            }
            child.put("receivedGifts", giftRecevied);
            annualChildren.add(child);
        }
        jsonChildren.put("children", annualChildren);
        array.add(jsonChildren);
    }
}
