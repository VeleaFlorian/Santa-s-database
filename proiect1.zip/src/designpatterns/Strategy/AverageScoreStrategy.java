package designpatterns.Strategy;

public interface AverageScoreStrategy {
    /**
     * Interface to be implemented by other strategies.
     */
    double getAverageScore();
}
