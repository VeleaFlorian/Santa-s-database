package children;

import designpatterns.factory.AverageScoreFactory;
import designpatterns.Strategy.AverageScoreStrategy;
import fileio.ChildrenUpdatesInputData;
import java.util.ArrayList;


public class UptadeChildrenData {

    public UptadeChildrenData(final ArrayList<Child> child,
                              final ArrayList<ChildrenUpdatesInputData> childrenUpdatesInputData) {
        for (int i = 0; i < childrenUpdatesInputData.size(); i++) {
            for (int k = 0; k < child.size(); k++) {
                if (childrenUpdatesInputData.get(i).getId() == child.get(k).getId()) {
                    if (childrenUpdatesInputData.get(i).getNiceScore() != -1) {
                        child.get(k).getNiceScoreHistory()
                                .add(childrenUpdatesInputData.get(i).getNiceScore());
                        AverageScoreStrategy averageScoreStrategy = new AverageScoreFactory()
                                .createStrategy(child.get(k));
                        child.get(k).setAverageScore(averageScoreStrategy.getAverageScore());
                    }
                    if (childrenUpdatesInputData.get(i).getGifts() != null) {
                        ArrayList<String> giftPreferences =
                                updateGiftPreferences(childrenUpdatesInputData.get(i).getGifts(),
                                child.get(k).getGiftsPreferences());

                        child.get(k).setGiftsPreferences(
                                giftPreferences);
                    }
                }
            }
        }
    }

    /**
     * Method to update the Gift Preferences of a child.
     * It checks if there are dublicates in the list, if so
     * deletes them. Adds the new preferences to the array.
     */

    public final ArrayList<String> updateGiftPreferences(final ArrayList<String> newPreferences,
                                                   final ArrayList<String> oldPreferences) {
        ArrayList<String> checkForDuplicates = new ArrayList<>();
        int found;
        for (int i = 0; i < newPreferences.size(); i++) {
            found = 0;
            for (int k = 0; k < checkForDuplicates.size(); k++) {
                if (checkForDuplicates.get(k).equals(newPreferences.get(i))) {
                    found = 1;
                    break;
                }
            }
            if (found == 0) {
                checkForDuplicates.add(newPreferences.get(i));
            }
        }

        for (int i = 0; i < oldPreferences.size(); i++) {
            found = 0;
            for (int k = 0; k < checkForDuplicates.size(); k++) {
                if (oldPreferences.get(i).equals(checkForDuplicates.get(k))) {
                    found = 1;
                    break;
                }
            }
            if (found == 0) {
                checkForDuplicates.add(oldPreferences.get(i));
            }
        }
        return checkForDuplicates;
    }

}
