package designpatterns.factory;

import children.Child;
import designpatterns.Strategy.AverageScoreStrategy;
import designpatterns.Strategy.BabyStrategy;
import designpatterns.Strategy.KidStrategy;
import designpatterns.Strategy.TeenStrategy;
import common.Constants;

public class AverageScoreFactory {
    /**
     * Method to create a strategy based on the age category the child is in.
     */
    public final AverageScoreStrategy createStrategy(final Child child) {
        if (child.getAgeCategory().equals(Constants.AgeCategory.BABY)) {
            return new BabyStrategy(child);
        } else if (child.getAgeCategory().equals(Constants.AgeCategory.KID)) {
            return new KidStrategy(child);
        } else if (child.getAgeCategory().equals(Constants.AgeCategory.TEEN)) {
            return new TeenStrategy(child);
        }
        return null;
    }
}
