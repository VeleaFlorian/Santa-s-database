package gifts;

import fileio.SantaGiftsInputData;

public class SantaGiftList implements Comparable<SantaGiftList> {
    private String productName;

    private String category;

    private double price;

    public SantaGiftList(final SantaGiftsInputData santaGiftsInputData) {
        this.productName = santaGiftsInputData.getProductName();
        this.category = santaGiftsInputData.getCategory();
        this.price = santaGiftsInputData.getPrice();
    }

    public final String getProductName() {
        return productName;
    }

    public final void setProductName(final String productName) {
        this.productName = productName;
    }

    public final String getCategory() {
        return category;
    }

    public final void setCategory(final String category) {
        this.category = category;
    }

    public final double getPrice() {
        return price;
    }

    public final void setPrice(final int price) {
        this.price = price;
    }

    @Override
    public final String toString() {
        return "SantaGiftList{"
                + "productName='"
                + productName
                + '\''
                + ", category='"
                + category
                + '\''
                + ", price="
                + price
                + '}';
    }


    @Override
    public final int compareTo(final SantaGiftList o) {
        if (this.getPrice() > o.getPrice()) {
            return 1;
        } else if (this.getPrice() == o.getPrice()) {
            return 0;
        } else {
            return -1;
        }
    }
}
