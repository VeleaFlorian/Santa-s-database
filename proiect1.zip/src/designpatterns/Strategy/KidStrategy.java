package designpatterns.Strategy;

import children.Child;

public class KidStrategy implements AverageScoreStrategy {

    private double sum = 0;

    public KidStrategy(final Child child) {
        if (child.getNiceScoreHistory().size() == 0) {
            sum = child.getAverageScore();
            child.getNiceScoreHistory().add(sum);
            return;
        }
        for (int i = 0; i < child.getNiceScoreHistory().size(); i++) {
            sum = sum + child.getNiceScoreHistory().get(i);
        }
        sum = sum / child.getNiceScoreHistory().size();
    }

    @Override
    public final double getAverageScore() {

        return sum;
    }
}
