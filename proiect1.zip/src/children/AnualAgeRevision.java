package children;

import designpatterns.factory.AgeCategoryFactory;
import designpatterns.factory.AverageScoreFactory;
import designpatterns.Strategy.AverageScoreStrategy;
import common.Constants;

import java.util.ArrayList;

public class AnualAgeRevision {
    public AnualAgeRevision(final ArrayList<Child> children,
                            final AgeCategoryFactory ageCategoryFactory) {
        addToAge(children);
        for (int i = 0; i < children.size(); i++) {
            ageCategoryFactory.ageCategory(children.get(i));
        }

        checkAge(children);

        for (int i = 0; i < children.size(); i++) {
            AverageScoreStrategy averageScoreStrategy = new AverageScoreFactory()
                    .createStrategy(children.get(i));
            children.get(i).setAverageScore(averageScoreStrategy.getAverageScore());
        }

    }

    /**
     * Method to add age to children.
     */
    public final void addToAge(final ArrayList<Child> children) {
        for (int i = 0; i < children.size(); i++) {
            children.get(i).setAge(children.get(i).getAge() + 1);
        }
    }

    /**
     * Method to check if they are Adults.
     * If so, delete them from the list.
     */
    public final void checkAge(final ArrayList<Child> children) {
        for (int i = 0; i < children.size(); i++) {
            if (children.get(i).getAgeCategory() == Constants.AgeCategory.ADULT) {
                children.remove(i);
                i--;
            }
        }
    }

}
