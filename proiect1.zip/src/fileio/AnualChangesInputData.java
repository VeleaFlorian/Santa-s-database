package fileio;

import java.util.ArrayList;

public class AnualChangesInputData {

    private final int newSantaBudget;

    private final ArrayList<SantaGiftsInputData> newGifts;

    private final ArrayList<ChildrenInputData> newChildren;

    private final ArrayList<ChildrenUpdatesInputData> childrenUpdates;


    public AnualChangesInputData(final int newSantaBudget,
                                 final ArrayList<ChildrenInputData> newChildren,
                                 final ArrayList<SantaGiftsInputData> newGifts,
                                 final ArrayList<ChildrenUpdatesInputData> childrenUpdates) {

        this.newSantaBudget = newSantaBudget;
        this.newChildren = newChildren;
        this.newGifts = newGifts;
        this.childrenUpdates = childrenUpdates;
    }

    public final int getNewSantaBudget() {
        return newSantaBudget;
    }

    public final ArrayList<SantaGiftsInputData> getNewGifts() {
        return newGifts;
    }

    public final ArrayList<ChildrenInputData> getNewChildren() {
        return newChildren;
    }

    public final ArrayList<ChildrenUpdatesInputData> getChildrenUpdates() {
        return childrenUpdates;
    }

    @Override
    public final String toString() {
        return "AnualChangesInputData{"
                + "newSantaBudget=" + newSantaBudget
                + ", newGifts=" + newGifts
                + ", newChildren=" + newChildren
                + ", ChildrenUpdates=" + childrenUpdates
                + '}';
    }
}
