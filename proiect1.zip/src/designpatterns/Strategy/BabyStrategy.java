package designpatterns.Strategy;

import children.Child;
import common.Constants;

public class BabyStrategy implements AverageScoreStrategy {

    private double sum;

    public BabyStrategy(final Child child) {
        if (child.getNiceScoreHistory().isEmpty()) {
            sum = child.getAverageScore();
            child.getNiceScoreHistory().add(sum);
            sum = Constants.BABYAVRSCORE;
            return;
        }
        sum = Constants.BABYAVRSCORE;
    }

    @Override
    public final double getAverageScore() {
        return sum;
    }
}
