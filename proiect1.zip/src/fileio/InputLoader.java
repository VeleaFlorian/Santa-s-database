package fileio;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import utils.Utils;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The class reads and parses the data from the tests
 * <p>
 * DO NOT MODIFY
 */
public final class InputLoader {
    /**
     * The path to the input file
     */
    private final String inputPath;

    public InputLoader(final String inputPath) {
        this.inputPath = inputPath;
    }

    public String getInputPath() {
        return inputPath;
    }

    /**
     * The method reads the database
     * @return an Input object
     */
    public Input readData() {
        JSONParser jsonParser = new JSONParser();
        Long numberOfYears = null;
        Long santaBudget = null;
        List<ChildrenInputData> children = new ArrayList<>();
        List<SantaGiftsInputData> gifts = new ArrayList<>();
        List<AnualChangesInputData> changes = new ArrayList<>();

        try {
            JSONObject jsonObject = (JSONObject) jsonParser
                    .parse(new FileReader(inputPath));
            numberOfYears = (Long) jsonObject.get("numberOfYears");
            santaBudget = (Long) jsonObject.get("santaBudget");
            JSONObject initialData = (JSONObject) jsonObject.get("initialData");
            JSONArray jsonChildren = (JSONArray)
                    initialData.get("children");
            JSONArray jsonGifts = (JSONArray)
                    initialData.get("santaGiftsList");
            JSONArray jsonChanges = (JSONArray)
                    jsonObject.get("annualChanges");
            if (jsonChildren != null) {
                for (Object jsonIterator : jsonChildren) {
                    children.add(new ChildrenInputData(
                            Integer.parseInt(((JSONObject) jsonIterator).get("id").toString()),
                            (String) ((JSONObject) jsonIterator).get("lastName"),
                            (String) ((JSONObject) jsonIterator).get("firstName"),
                            Integer.parseInt(((JSONObject) jsonIterator).get("age").toString()),
                            (String) ((JSONObject) jsonIterator).get("city"),
                            (double) Integer.parseInt(((JSONObject) jsonIterator).get("niceScore")
                                    .toString()),
                            Utils.convertJSONArray((JSONArray) ((JSONObject) jsonIterator)
                                    .get("giftsPreferences"))
                    ));
                }
            } else {
                System.out.println("NU EXISTA SERIALE");
            }
            if (jsonGifts != null) {
                for (Object jsonIterator : jsonGifts) {
                    gifts.add(new SantaGiftsInputData(
                            (String) ((JSONObject) jsonIterator).get("productName"),
                            Integer.parseInt(((JSONObject) jsonIterator).get("price")
                                    .toString()),
                            (String) ((JSONObject) jsonIterator).get("category")
                    ));
                }
            } else {
                System.out.println("NU EXISTA FILME");
            }
            if (jsonChanges != null) {
                for (Object jsonIterator : jsonChanges) {
                    ArrayList<SantaGiftsInputData> newGifts = new ArrayList<>();
                    if (((JSONObject) jsonIterator).get("newGifts") != null) {
                        for (Object iterator : (JSONArray) ((JSONObject) jsonIterator)
                                .get("newGifts")) {
                            newGifts.add(new SantaGiftsInputData(
                                    (String) ((JSONObject) iterator).get("productName"),
                                    Integer.parseInt(((JSONObject) iterator).get("price")
                                            .toString()),
                                    (String) ((JSONObject) iterator).get("category")
                            ));
                        }
                    } else {
                        newGifts = null;
                    }
                    ArrayList<ChildrenInputData> newChildren = new ArrayList<>();
                    if (((JSONObject) jsonIterator).get("newChildren") != null) {
                        for (Object iterator : (JSONArray) ((JSONObject) jsonIterator)
                                .get("newChildren")) {
                            newChildren.add(new ChildrenInputData(
                                    Integer.parseInt(((JSONObject) iterator).get("id").toString()),
                                    (String) ((JSONObject) iterator).get("lastName"),
                                    (String) ((JSONObject) iterator).get("firstName"),
                                    Integer.parseInt(((JSONObject) iterator).get("age").toString()),
                                    (String) ((JSONObject) iterator).get("city"),
                                    (double) Integer.parseInt(((JSONObject) iterator)
                                            .get("niceScore").toString()),
                                    Utils.convertJSONArray((JSONArray) ((JSONObject) iterator)
                                            .get("giftsPreferences"))
                            ));
                        }
                    } else {
                        newChildren = null;
                    }
                    ArrayList<ChildrenUpdatesInputData> childrenUpdates = new ArrayList<>();
                    if (((JSONObject) jsonIterator).get("childrenUpdates") != null) {
                        for (Object iterator : (JSONArray) ((JSONObject) jsonIterator)
                                .get("childrenUpdates")) {
                            if (((JSONObject) iterator).get("niceScore") == null) {
                                childrenUpdates.add(new ChildrenUpdatesInputData(
                                        Integer.parseInt(((JSONObject) iterator).get("id")
                                                .toString()),
                                        (double) -1,
                                        Utils.convertJSONArray((JSONArray) ((JSONObject) iterator)
                                                .get("giftsPreferences"))
                                ));
                            } else {
                                childrenUpdates.add(new ChildrenUpdatesInputData(
                                        Integer.parseInt(((JSONObject) iterator).get("id")
                                                .toString()),
                                        (double) Integer.parseInt(((JSONObject) iterator)
                                                .get("niceScore").toString()),
                                        Utils.convertJSONArray((JSONArray) ((JSONObject) iterator)
                                                .get("giftsPreferences"))
                                ));
                            }
                        }
                    } else {
                        childrenUpdates = null;
                    }
                    changes.add(new AnualChangesInputData(
                            Integer.parseInt(((JSONObject) jsonIterator)
                                    .get("newSantaBudget").toString()),
                            newChildren,
                            newGifts,
                            childrenUpdates
                    ));
                }
            } else {
                System.out.println("NU EXISTA FILME");
            }

            if (numberOfYears == null) {
                numberOfYears = null;
            }
            if (santaBudget == null) {
                santaBudget = null;
            }
            if (jsonChildren == null) {
                children = null;
            }
            if (jsonGifts == null) {
                gifts = null;
            }
            if (jsonChanges == null) {
                changes = null;
            }
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return new Input(numberOfYears, santaBudget, children, gifts, changes);
    }


}
