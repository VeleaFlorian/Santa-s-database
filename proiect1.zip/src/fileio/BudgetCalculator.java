package fileio;

import children.Child;

import java.util.List;

public class BudgetCalculator {

    private double budget;

    public BudgetCalculator(final double santaBudget, final List<Child> children) {
        double sumAverageScore = 0;
        for (int i = 0; i < children.size(); i++) {
            sumAverageScore = sumAverageScore + children.get(i).getAverageScore();
        }
        budget = santaBudget / sumAverageScore;
        for (int i = 0; i < children.size(); i++) {
            children.get(i).setAssignedBudget(budget * children.get(i).getAverageScore());
        }
    }
}
