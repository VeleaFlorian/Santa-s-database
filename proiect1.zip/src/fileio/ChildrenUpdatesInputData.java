package fileio;

import java.util.ArrayList;

public class ChildrenUpdatesInputData extends ShowInput {
    public ChildrenUpdatesInputData(final Integer id,
                                    final Double niceScore,
                                    final ArrayList<String> gifts) {
        super(id, niceScore, gifts);
    }

    @Override
    public final String toString() {
        return "ChildrenUpdatesInputData{} " + super.toString();
    }
}
